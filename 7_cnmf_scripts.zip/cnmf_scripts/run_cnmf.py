from cnmf import cNMF
import sys
n_workers = int(sys.argv[1])
worker_id = int(sys.argv[2])

output_directory = "cnmf_2_51_2000"
run_name = output_directory
cnmf_obj = cNMF(output_dir=output_directory, name=run_name)
cnmf_obj.factorize(worker_i=worker_id, total_workers=n_workers)