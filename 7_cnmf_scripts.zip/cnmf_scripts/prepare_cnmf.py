import os
import numpy as np
import scanpy as sc
import sys
from cnmf import cNMF

start_k = int(sys.argv[1])
end_k = int(sys.argv[2])
n_genes = int(sys.argv[3])
counts_file = sys.argv[4]


output_directory = f"cnmf_{start_k}_{end_k}_{n_genes}"

if not os.path.exists(output_directory):
  os.mkdir(output_directory)

run_name = output_directory
countfn = counts_file


cnmf_obj = cNMF(output_dir=output_directory, name=run_name)
cnmf_obj.prepare(counts_fn=countfn, components=np.arange(start_k, end_k+1), n_iter=200, seed=14, num_highvar_genes=n_genes)
