from cnmf import cNMF

output_directory = 'cnmf_2_51_2000'
run_name = 'cnmf_2_51_2000'

cnmf_obj = cNMF(output_dir=output_directory, name=run_name)
cnmf_obj.combine()