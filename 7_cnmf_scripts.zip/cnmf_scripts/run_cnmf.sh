#!/bin/bash

# Input parameters
n_workers=$1
worker_id=$2

# Allocate 3GB of memory by creating a dummy file that simulates memory usage
large_string1=$(yes "dummy_data" | head -c 100M)
large_string2=$(yes "dummy_data" | head -c 100M)
large_string3=$(yes "dummy_data" | head -c 100M)
large_string4=$(yes "dummy_data" | head -c 100M)
large_string5=$(yes "dummy_data" | head -c 100M)
large_string6=$(yes "dummy_data" | head -c 100M)
large_string7=$(yes "dummy_data" | head -c 100M)
large_string8=$(yes "dummy_data" | head -c 100M)
large_string9=$(yes "dummy_data" | head -c 100M)
large_string10=$(yes "dummy_data" | head -c 100M)
large_string11=$(yes "dummy_data" | head -c 100M)
large_string12=$(yes "dummy_data" | head -c 100M)
large_string13=$(yes "dummy_data" | head -c 100M)
large_string14=$(yes "dummy_data" | head -c 100M)
large_string15=$(yes "dummy_data" | head -c 100M)
large_string16=$(yes "dummy_data" | head -c 100M)
large_string17=$(yes "dummy_data" | head -c 100M)
large_string18=$(yes "dummy_data" | head -c 100M)
large_string19=$(yes "dummy_data" | head -c 100M)
large_string20=$(yes "dummy_data" | head -c 100M)
large_string21=$(yes "dummy_data" | head -c 100M)
large_string22=$(yes "dummy_data" | head -c 100M)
large_string23=$(yes "dummy_data" | head -c 100M)
large_string24=$(yes "dummy_data" | head -c 100M)
large_string25=$(yes "dummy_data" | head -c 100M)
large_string26=$(yes "dummy_data" | head -c 100M)
large_string27=$(yes "dummy_data" | head -c 100M)
large_string28=$(yes "dummy_data" | head -c 100M)
large_string29=$(yes "dummy_data" | head -c 100M)
large_string30=$(yes "dummy_data" | head -c 100M)
large_string31=$(yes "dummy_data" | head -c 100M)
large_string32=$(yes "dummy_data" | head -c 100M)
large_string33=$(yes "dummy_data" | head -c 100M)
large_string34=$(yes "dummy_data" | head -c 100M)
large_string35=$(yes "dummy_data" | head -c 100M)
large_string36=$(yes "dummy_data" | head -c 100M)
large_string37=$(yes "dummy_data" | head -c 100M)
large_string38=$(yes "dummy_data" | head -c 100M)
large_string39=$(yes "dummy_data" | head -c 100M)
large_string40=$(yes "dummy_data" | head -c 100M)

/Local/md_keren/anaconda3/envs/SigProfilerExtractor/bin/python run_cnmf.py $n_workers $worker_id