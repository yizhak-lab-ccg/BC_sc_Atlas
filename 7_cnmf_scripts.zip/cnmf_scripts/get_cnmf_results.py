import sys
import os
import pandas as pd
from cnmf import cNMF

output_directory = 'cnmf_2_31_2000'
run_name = 'cnmf_2_31_2000'

cnmf_obj = cNMF(output_dir=output_directory, name=run_name)

selected_K = int(sys.argv[1])
density_threshold = float(sys.argv[2])

usage_norm, gep_scores, gep_tpm, topgenes = cnmf_obj.load_results(K=selected_K, density_threshold=density_threshold)

results_path = os.path.join("cnmf_2_31_2000",f"results_{selected_K}_{density_threshold}")
if not os.path.exists(results_path):
  os.makedirs(results_path)

usage_norm.to_csv(os.path.join(results_path, "usage.csv"))
gep_scores.to_csv(os.path.join(results_path, "gep_scores.csv"))
gep_tpm.to_csv(os.path.join(results_path, "gep_tpm.csv"))
topgenes.to_csv(os.path.join(results_path, "topgenes.csv"))