import numpy as np
import sys

n_workers = int(sys.argv[1])

with open(f"arguments_for_cnmf_{n_workers}.txt", "w") as f:
    for worker in np.arange(0, n_workers):
        f.write(f"{n_workers},{worker}\n")