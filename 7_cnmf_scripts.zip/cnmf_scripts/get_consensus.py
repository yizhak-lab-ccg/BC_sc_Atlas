import sys
from cnmf import cNMF

output_directory = 'cnmf_2_31_2000'
run_name = 'cnmf_2_31_2000'
cnmf_obj = cNMF(output_dir=output_directory, name=run_name)

# Ensure X is consistently float64 to avoid dtype errors
if hasattr(cnmf_obj, 'norm_tpm') and hasattr(cnmf_obj.norm_tpm, 'X'):
    cnmf_obj.norm_tpm.X = cnmf_obj.norm_tpm.X.astype('float64')

selected_K = int(sys.argv[1])
density_threshold = float(sys.argv[2])

cnmf_obj.consensus(k=selected_K, density_threshold=density_threshold, show_clustering=True, close_clustergram_fig=False)
