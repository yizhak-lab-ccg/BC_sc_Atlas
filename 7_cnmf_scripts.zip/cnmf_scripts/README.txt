Scripts to run cNMF through condor:

1. create_arguments_for_cnmf.py
makes the arguments file with n_workers,worker_id

2. prepare_cnmf.py
creates the output directory and runs cNMF. prepare with the range of k's and the number of top variable genes to used

3. run_cnmf.sh
shell wrapper that takes n_workers and worker_id and calls run_cnmf.py

4. run_cnmf.py
runs one factorization job for a worker (runed using run_cnmf.submit)

5. combine_cnmf.py
combines all job results

6. create_selection_plot.py
makes the plot to choose K and threshold

7. get_consensus.py
runs consensus for chosen K and threshold

8. get_cnmf_results.py
saves usage, GEP scores, TPM, and top genes
