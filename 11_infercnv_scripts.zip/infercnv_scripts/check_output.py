file_names = """cellProbs.0.5.pdf
cnvProbs.0.5.pdf
infercnv.NormalProbabilities.PostFiltering.heatmap_thresholds.txt
infercnv.NormalProbabilities.PostFiltering.observation_groupings.txt
infercnv.NormalProbabilities.PostFiltering.png
infercnv.NormalProbabilities.PreFiltering.heatmap_thresholds.txt
infercnv.NormalProbabilities.PreFiltering.observation_groupings.txt
infercnv.NormalProbabilities.PreFiltering.png
MCMC_inferCNV_obj.rds
"""
file_names = file_names.split()
import os

for folder in os.listdir('infercnv_results'):
    try:
        all_files = os.listdir(os.path.join('infercnv_results', folder, 'BayesNetOutput.HMMi6.leiden.hmm_mode-subclusters'))
        for file in file_names:
            if file not in all_files:
                print(folder, file)
    except:
      print('no folder', folder)