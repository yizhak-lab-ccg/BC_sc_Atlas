#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(Matrix)
  library(data.table)
  library(infercnv)
  library(tools)
})


args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1) {
  stop("Usage: Rscript run_infercnv.R <subset_folder>")
}

subset_dir <- file.path("infercnv_subsets", args[1])
if (!dir.exists(subset_dir)) stop(paste("Folder not found:", subset_dir))


prefix <- file_path_sans_ext(args[1])
output_dir <- file.path("infercnv_results", prefix)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)


gene_order_file <- "g.txt"
if (!file.exists(gene_order_file)) stop("g.txt gene order file not found.")


cat("Reading matrix.mtx from:", subset_dir, "\n")
expr <- readMM(file.path(subset_dir, "matrix.mtx"))
genes <- fread(file.path(subset_dir, "genes.tsv"), header = FALSE)[[1]]
cells <- fread(file.path(subset_dir, "barcodes.tsv"), header = FALSE)[[1]]


expr <- Matrix::t(expr)


rownames(expr) <- genes
colnames(expr) <- cells


expr <- as(expr, "CsparseMatrix")


obs <- fread(file.path(subset_dir, "cell_metadata.tsv"))
obs$cell <- rownames(obs) <- obs[[1]]
if (!"BIOPSY_GROUP" %in% colnames(obs)) stop("Missing 'BIOPSY_GROUP' column in cell_metadata.tsv")

annotations <- obs[, .(cell, BIOPSY_GROUP)]
annot_file <- file.path(output_dir, "cell_annotations.txt")
write.table(annotations, annot_file, sep = "\t", quote = FALSE, row.names = FALSE, col.names = FALSE)

gene_order <- fread(gene_order_file, header = FALSE)
if (ncol(gene_order) != 4) stop("Gene order must have 4 columns: gene, chr, start, end.")
gene_order_path <- file.path(output_dir, "gene_order_used.txt")
write.table(gene_order, gene_order_path, sep = "\t", quote = FALSE, row.names = FALSE, col.names = FALSE)

valid_refs <- intersect(
  c("BREAST_STROMA", "MET_STROMA", "LN_STROMA", 
    "BREAST_IMMUNE", "LN_IMMUNE", "MET_IMMUNE"),
  unique(annotations$BIOPSY_GROUP)
)

if (length(valid_refs) == 0) {
  stop(paste("No valid reference groups found for:", prefix))
}


cat("Running infercnv on", prefix, "\n")
infercnv_obj <- CreateInfercnvObject(
  raw_counts_matrix = expr,
  annotations_file = annot_file,
  gene_order_file = gene_order_path,
  ref_group_names = valid_refs
)

infercnv_obj <- infercnv::run(
  infercnv_obj,
  cutoff = 0,
  out_dir = output_dir,
  cluster_by_groups = TRUE,
  denoise = TRUE,
  HMM = TRUE,
  no_prelim_plot = TRUE,
  png_res = 300,
  analysis_mode = "subclusters",
  leiden_resolution = 0.001,
  write_expr_matrix = TRUE,
  num_threads = 8
)

cat("Done:", prefix, "output saved to", output_dir, "\n")
