create_anndata.py – Builds AnnData objects from the integrated count CSV.

create_part_sample_adata_subsets.py – Splits the integrated CSV into subsets by tumor type and stage.

run_infercnv.R – R script that runs the inferCNV analysis.

check_output.py – Extracts only the essential inferCNV output files.