import os
import numpy as np
import pandas as pd
import scanpy as sc
import scipy.io


MAX_TUMOR_CELLS = 3000
MAX_NORMAL_CELLS = 300
MIN_TUMOR_CELLS = 50

# balanced sampling of normals
def smart_balanced_sample(normals_df: pd.DataFrame, max_normals=300) -> pd.DataFrame:
    immune_df = normals_df[normals_df['TYPE'] == 'IMMUNE']
    stroma_df = normals_df[normals_df['TYPE'] == 'STROMA']
    n_immune, n_stroma = len(immune_df), len(stroma_df)
    total = n_immune + n_stroma
    if total <= max_normals:
        return normals_df
    # decide which pool is smaller
    if n_immune <= n_stroma:
        small_df, small_n = immune_df, n_immune
        large_df, large_n = stroma_df, n_stroma
    else:
        small_df, small_n = stroma_df, n_stroma
        large_df, large_n = immune_df, n_immune
    take_small = min(max_normals // 2, small_n)
    sampled_small = small_df.sample(n=take_small, random_state=42, replace=False)
    remaining = max_normals - take_small
    take_large = min(remaining, large_n)
    sampled_large = large_df.sample(n=take_large, random_state=42, replace=False)
    return pd.concat([sampled_small, sampled_large])


adata = sc.read_h5ad('All_cells_adata.h5ad')
adata.obs_names_make_unique()

negative_count = [int(i[0]) for i in (adata.X < 0).sum(axis = 1)]
adata.obs['negative_count'] = negative_count
adata = adata[adata.obs['negative_count'] == 0]


# Original series
patient_ser = adata.obs['patient']

patient_num = pd.to_numeric(patient_ser, errors='coerce')

new_patient = [
    int(num) if not np.isnan(num) else orig
    for orig, num in zip(patient_ser, patient_num)
]

adata.obs['patient'] = new_patient
adata.obs['patient'] = adata.obs['patient'].astype(str)

adata.obs['BIOPSY_GROUP'] = np.where(
    adata.obs['BIOPSY'] == 'BREAST', 'BREAST',
    np.where(
        adata.obs['BIOPSY'] == 'LN', 'LN',
        np.where(
            adata.obs['BIOPSY'].isin(['BLOOD', 'NA', 'nan']), np.nan,
            'MET'
        )
    )
)


adata.obs['BIOPSY_GROUP'] = adata.obs['BIOPSY_GROUP'].astype(str) + '_' + adata.obs['TYPE'].astype(str)

os.makedirs("infercnv_subsets", exist_ok=True)
summary_rows = []

for paper in adata.obs['paper'].unique():
    paper_adata = adata[adata.obs['paper'] == paper]
    
    # Sample normals ONCE for this paper
    normals_obs = paper_adata[paper_adata.obs['TYPE'] != 'TUMOR'].obs
    sampled_normals = smart_balanced_sample(normals_obs, max_normals=MAX_NORMAL_CELLS)
    normal_barcodes = sampled_normals.index.tolist()
    before_counts = normals_obs['TYPE'].value_counts()

    for cancer in paper_adata.obs['C.TYPE'].unique():
        cancer_adata = paper_adata[paper_adata.obs['C.TYPE'] == cancer]
        tumor_all = cancer_adata[cancer_adata.obs['TYPE'] == 'TUMOR']
        n_tumor_all = tumor_all.n_obs
        
        if n_tumor_all < MIN_TUMOR_CELLS:
            print(f"Skipping {(paper, cancer)}: only {n_tumor_all} tumour cells (<{MIN_TUMOR_CELLS})")
            continue
        # 1) Cancer-level FULL subset if small
        if n_tumor_all <= MAX_TUMOR_CELLS:
            key = f"{paper}_{cancer}_full".replace(" ", "_")
            outdir = os.path.join("infercnv_subsets", key)
            os.makedirs(outdir, exist_ok=True)
            combined_bcs = tumor_all.obs_names.tolist() + normal_barcodes
            combined = adata[combined_bcs].copy()
            
            # write files
            combined.write_h5ad(f"{outdir}/{key}.h5ad")
            scipy.io.mmwrite(f"{outdir}/matrix.mtx", combined.X)
            pd.DataFrame(combined.obs_names).to_csv(
                f"{outdir}/barcodes.tsv", index=False, header=False
            )
            pd.DataFrame(combined.var_names).to_csv(
                f"{outdir}/genes.tsv", index=False, header=False
            )
            combined.obs.to_csv(f"{outdir}/cell_metadata.tsv", sep="\t")
            
            # record summary
            after = combined.obs['TYPE'].value_counts()
            summary_rows.append({
                "paper": paper,
                "cancer": cancer,
                "sample": "ALL",
                "chunk": 0,
                "TUMOR_n": after.get("TUMOR", 0),
                "IMMUNE_before": before_counts.get("IMMUNE", 0),
                "STROMA_before": before_counts.get("STROMA", 0),
                "IMMUNE_after": after.get("IMMUNE", 0),
                "STROMA_after": after.get("STROMA", 0),
            })
            continue
        
        # 2) Sample-level chunking
        for sample in tumor_all.obs['patient'].unique():
            samp_grp = tumor_all[tumor_all.obs['patient'] == sample]
            bcs = samp_grp.obs_names.tolist()
            np.random.seed(42)
            np.random.shuffle(bcs)
            n_chunks = int(np.ceil(len(bcs) / MAX_TUMOR_CELLS))
            chunks = np.array_split(bcs, n_chunks)
            
            for idx, chunk in enumerate(chunks):
                if samp_grp.n_obs < MIN_TUMOR_CELLS:
                    print(f"Skipping {sample}: only {samp_grp.n_obs} tumour cells (<{MIN_TUMOR_CELLS})")
                    continue
                chunk = list(chunk)
                key = f"{paper}_{cancer}_{sample}_part{idx}".replace(" ", "_")
                outdir = os.path.join("infercnv_subsets", key)
                os.makedirs(outdir, exist_ok=True)
                
                combined_bcs = chunk + normal_barcodes
                combined = adata[combined_bcs].copy()
                
                # write files
                combined.write_h5ad(f"{outdir}/{key}.h5ad")
                scipy.io.mmwrite(f"{outdir}/matrix.mtx", combined.X)
                pd.DataFrame(combined.obs_names).to_csv(
                    f"{outdir}/barcodes.tsv", index=False, header=False
                )
                pd.DataFrame(combined.var_names).to_csv(
                    f"{outdir}/genes.tsv", index=False, header=False
                )
                combined.obs.to_csv(f"{outdir}/cell_metadata.tsv", sep="\t")
                
                # record summary
                after = combined.obs['TYPE'].value_counts()
                summary_rows.append({
                    "paper": paper,
                    "cancer": cancer,
                    "sample": sample,
                    "chunk": idx,
                    "TUMOR_n": after.get("TUMOR", 0),
                    "IMMUNE_before": before_counts.get("IMMUNE", 0),
                    "STROMA_before": before_counts.get("STROMA", 0),
                    "IMMUNE_after": after.get("IMMUNE", 0),
                    "STROMA_after": after.get("STROMA", 0),
                })


summary_df = pd.DataFrame(summary_rows)
summary_df = summary_df.sort_values(["paper","cancer","sample","chunk"])
summary_df.to_csv("cell_type_sample_part_summary.csv", index=False)
print("Done. Summary:")
print(summary_df.head())
