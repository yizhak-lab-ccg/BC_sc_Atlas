import numpy as np
import scanpy as sc
import pandas as pd
from collections import defaultdict
import os
import anndata as ad
from scipy.sparse import csr_matrix
expression_df = pd.read_csv('All_cells_expression.csv', index_col = 0)
metadata_df = pd.read_csv('All_cells_metadata.csv', index_col = 0)

adata = ad.AnnData(csr_matrix(expression_df))
adata.obs = metadata_df


# Load adata and clean
adata = sc.write('All_cells_adata.h5ad')